<a href="<?php echo e(route('filament.admin.pages.dashboard')); ?>" class="fi-topbar-logo flex items-center mr-4">
    <img src="<?php echo e(asset('images/fintrack-logo.svg')); ?>" alt="Fintrack Logo" class="h-8 w-auto" />
</a>
<?php /**PATH C:\Users\Home\github\home_project\dla\proter-fintrack\proter-fintrack\resources\views/filament/components/topbar-logo.blade.php ENDPATH**/ ?>