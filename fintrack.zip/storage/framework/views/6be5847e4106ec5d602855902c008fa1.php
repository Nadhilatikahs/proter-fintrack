<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="ft-cat-layout">
        
        <div class="ft-cat-header">
            <h1 class="ft-page-title"></h1>

            <a
                href="<?php echo e(route('filament.admin.resources.categories.create')); ?>"
                class="fin-btn-outline-green"
            >
                + Input Categories
            </a>
        </div>

        
        <div class="ft-cat-table-head">
            <span class="ft-cat-head-label">Date</span>
            <span class="ft-cat-head-label">Category</span>
            <span class="ft-cat-head-label text-right">Actions</span>
        </div>

        
        <div class="ft-cat-list">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="ft-cat-row">
                    <div class="ft-cat-date">
                        <?php echo e(optional($category->created_at)->format('d F Y') ?? '-'); ?>

                    </div>

                    <div class="ft-cat-name">
                        <span class="ft-pill ft-pill-category">
                            <?php echo e($category->name); ?>

                        </span>
                    </div>

                    <div class="ft-cat-actions">
                        <a
                            href="<?php echo e(route('filament.admin.resources.categories.edit', $category)); ?>"
                            class="fin-btn-dark"
                        >
                            Edit
                        </a>

                        <button
                            type="button"
                            class="fin-btn-red"
                            wire:click="confirmDelete(<?php echo e($category->id); ?>)"
                        >
                            Delete
                        </button>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="ft-empty-text">
                    Belum ada kategori.
                    Klik <strong>+ Input Categories</strong> untuk menambahkan.
                </p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showDeleteModal): ?>
            <div class="ft-modal-backdrop">
                <div class="ft-modal">
                    <div class="ft-modal-title">
                        Delete category
                    </div>
                    <div class="ft-modal-text">
                        Are you sure you want to delete this category?<br>
                        <span class="text-red-600 font-semibold">
                            This action cannot be undone.
                        </span>
                    </div>
                    <div class="ft-modal-actions">
                        <button
                            type="button"
                            class="fin-btn-dark"
                            wire:click="$set('showDeleteModal', false)"
                        >
                            Cancel
                        </button>
                        <button
                            type="button"
                            class="fin-btn-red"
                            wire:click="deleteConfirmed"
                        >
                            Delete
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Home\github\home_project\dla\proter-fintrack\proter-fintrack\resources\views/filament/pages/categories-overview.blade.php ENDPATH**/ ?>